$document.ready() 
{
  
}
