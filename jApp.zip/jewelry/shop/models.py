from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class MetalType(models.Model):
    metal_type = models.CharField(max_length = 30)

    def __str__(self):
        return self.metal_type


class Category(models.Model):
    metal_type = models.ForeignKey(MetalType,on_delete=models.CASCADE)
    c_name = models.CharField(max_length = 50)

    def __str__(self):
        return self.c_name


class Product(models.Model):
    category = models.ForeignKey(Category,on_delete=models.CASCADE)
    p_name = models.CharField(max_length = 100)
    p_detail = models.TextField()
    p_cost = models.DecimalField(max_digits = 10, decimal_places = 2)
    p_photo = models.ImageField(blank=True, upload_to='product_photo')

    def __str__(self):
        return self.p_name


class ReviewProduct(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    product = models.ForeignKey(Product,on_delete=models.CASCADE)
    review = models.TextField()
    rating = models.IntegerField(default = 1)

    def __str__(self):
        return self.user.name,self.product.name


class ItemPurchase(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    product = models.ForeignKey(Product,on_delete=models.CASCADE)
    is_purchased = models.BooleanField(default=False)
    quantity = models.IntegerField(default=0)

    def __str__(self):
        return self.user,self.product,self.is_purchased,self.quantity



class ShoppingDetail(models.Model):
    full_name = models.CharField(max_length = 100)
    street = models.CharField(max_length = 100)
    town = models.CharField(max_length = 100)
    district = models.CharField(max_length = 100)
    state = models.CharField(max_length = 100)
    country = models.CharField(max_length = 100)
    pin = models.IntegerField()

    def __str__(self):
        return self.full_name,self.country,self.pin

